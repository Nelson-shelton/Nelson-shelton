/**
 * Horizontal Menu
 */
import React, { Component } from 'react';

import IntlMessages from 'Util/IntlMessages';

import navLinks from './NavLinks';

import NavMenuItem from './NavMenuItem';

class HorizontalMenu extends Component {
	render() {
		return (
			<div className="horizontal-menu">
				<ul className="list-unstyled nav">
				 



				</ul>
			</div>
		);
	}
}

export default HorizontalMenu;
