// Agency nav links
export default {

   category2: [
      {
         "menu_title": "sidebar.dashboard",
         "menu_icon": "zmdi zmdi-email",
         "path": "/dashboard/patientDetails",
         "new_item": false,
         "child_routes": null
      },
      {
         "menu_title": "sidebar.calenderView",
         "menu_icon": "zmdi zmdi-comments",
         "path": "/calendar/selectable",
         "new_item": false,
         "child_routes": null
      },
      {
         "menu_title": "sidebar.generalExam",
         "menu_icon": "zmdi zmdi-comment-text-alt",
         "path": "/forms/select-list",
         "new_item": false,
         "child_routes": null
      }
   ]

}
