export const clientsData = [
   {
      id: 1,
      image: "user-1.jpg",
      name: "Jerry Ried",
      e_mail: "JerryBRied@jourrapide.com",
      phone_number: "+1 207-589-4752",
      country: "Liberty",
      type: "recently_added"
   },
   {
      id: 2,
      image: "user-2.jpg",
      name: "Gustavo Stevenson",
      e_mail: "GustavoJStevenson@rhyta.com",
      phone_number: "+1 727-709-5505",
      country: "Tampa",
      type: "recently_added"
   },
   {
      id: 3,
      image: "user-3.jpg",
      name: "John Shrum",
      e_mail: "JohnLShrum@jourrapide.com ",
      phone_number: "+1 650-722-2798",
      country: "San Francisco",
      type: "recently_added"
   },
   {
      id: 4,
      image: "user-4.jpg",
      name: "Julie Reno",
      e_mail: "JulieDReno@dayrep.com",
      phone_number: "+1 956-303-4288",
      country: "Harlingen",
      type: "favourite"
   },
   {
      id: 5,
      image: "user-5.jpg",
      name: "Nancy Beck",
      e_mail: "NancyKBeck@teleworm.us",
      phone_number: "+1 423-954-4020",
      country: "Chattanooga",
      type: "favourite"
   },
   {
      id: 6,
      image: "user-6.jpg",
      name: "Travis Klotz",
      e_mail: "TravisMKlotz@jourrapide.com",
      phone_number: "+1 312-405-5954",
      country: "Hickory Hills",
      type: "favourite"
   },
   {
      id: 7,
      image: "user-7.jpg",
      name: "Anna Estes",
      e_mail: "AnnaLEstes@armyspy.com",
      phone_number: "+1 808-652-9469",
      country: "Waipahu",
      type: "favourite"
   },
   {
      id: 8,
      image: "user-8.jpg",
      name: "David Jones",
      e_mail: "DavidDJones@jourrapide.com",
      phone_number: "+1 407-343-1604",
      country: "Kissimmee",
      type: "favourite"
   },
   {
      id: 9,
      image: "user-9.jpg",
      name: "Hayden Bower",
      e_mail: "HaydenMBower@armyspy.com",
      phone_number: "+1 601-298-5772",
      country: "Carthage",
      type: "favourite"
   },
   {
      id: 10,
      image: "user-10.jpg",
      name: "Cathy Hagood",
      e_mail: "CathyWHagood@jourrapide.com",
      phone_number: "+1 325-660-7801",
      country: "Abilene",
      type: "recently_added"
   },
   {
      id: 11,
      image: "user-11.jpg",
      name: "Anna Estes",
      e_mail: "AnnaLEstes@armyspy.com",
      phone_number: "+1 808-652-9469",
      country: "Waipahu",
      type: "recently_added"
   },
   {
      id: 12,
      image: "user-12.jpg",
      name: "Mary Perez",
      e_mail: "MaryJPerez@teleworm.us",
      phone_number: "+1 626-374-4199",
      country: "Alhambra",
      type: "recently_added"
   },
   {
      id: 13,
      image: "user-13.jpg",
      name: "Jerry Ried",
      e_mail: "JerryBRied@jourrapide.com",
      phone_number: "+1 207-589-4752",
      country: "Liberty",
      type: "recently_added"
   },
   {
      id: 14,
      image: "user-14.jpg",
      name: "Gustavo Stevenson",
      e_mail: "GustavoJStevenson@rhyta.com",
      phone_number: "+1 727-709-5505",
      country: "Tampa",
      type: "recently_added"
   },
   {
      id: 15,
      image: "user-15.jpg",
      name: "John Shrum",
      e_mail: "JohnLShrum@jourrapide.com ",
      phone_number: "+1 650-722-2798",
      country: "San Francisco",
      type: "favourite"
   },
   {
      id: 16,
      image: "user-16.jpg",
      name: "Julie Reno",
      e_mail: "JulieDReno@dayrep.com",
      phone_number: "+1 956-303-4288",
      country: "Harlingen",
      type: "favourite"
   }
]